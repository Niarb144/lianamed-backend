# Health Backend (Node.js + Express + MongoDB)

Follow the README generated earlier. Ensure you copy .env.example to .env and set MONGO_URI and JWT_SECRET.
